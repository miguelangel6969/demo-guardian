import {Component, ElementRef, ViewChild} from '@angular/core';
import {Button} from 'primeng/button';

@Component({
  selector: 'app-upload',
  imports: [
    Button
  ],
  templateUrl: './upload.component.html',
  styleUrl: './upload.component.css'
})
export class UploadComponent {
  selectedFile: File | null = null;
  uploadedFileName: string | null = null;

  showFileInput = true; // Nuevo control para el input

  @ViewChild('fileInput') fileInputRef!: ElementRef<HTMLInputElement>;

  onFileSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  onUpload() {
    if (this.selectedFile) {
      console.log('Subiendo archivo:', this.selectedFile.name);
      this.uploadedFileName = this.selectedFile.name;
    }
  }

  onClear() {
    this.selectedFile = null;
    this.uploadedFileName = null;

    // Forzar que el input se destruya y se vuelva a crear
    this.showFileInput = false;
    setTimeout(() => {
      this.showFileInput = true;
    }, 0);
  }

  onDownloadTemplate() {
    // lógica de descarga aquí
  }
}
