import {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
} from "./chunk-SZ75A6OD.js";
import "./chunk-TLL2XKOX.js";
import "./chunk-DKOZKAI5.js";
import "./chunk-P6U2JBMQ.js";
import "./chunk-WDMUDEB6.js";
export {
  PRIME_NG_CONFIG,
  PrimeNG,
  ThemeProvider,
  providePrimeNG
};
//# sourceMappingURL=primeng_config.js.map
